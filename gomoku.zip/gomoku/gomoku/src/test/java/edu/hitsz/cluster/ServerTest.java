package edu.hitsz.cluster;

import edu.hitsz.cluster.server.Server;

/**
 * Created by Neuclil on 17-4-15.
 */
public class ServerTest {

    public static void main(String[] args) {
        Server server = new Server();
        server.start();
    }
}
