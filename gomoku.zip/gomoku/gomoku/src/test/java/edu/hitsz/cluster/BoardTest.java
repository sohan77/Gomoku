package edu.hitsz.cluster;

import edu.hitsz.cluster.client.Client;
import org.junit.Test;

/**
 * Created by Neuclil on 17-4-15.
 */
public class BoardTest {

    @Test
    public void testInit(){

    }
}
