package edu.hitsz.cluster;

import edu.hitsz.cluster.client.Client;

/**
 * Created by Neuclil on 17-4-15.
 */
public class Client1Test {

    public static void main(String[] args) {
        Client client = new Client();
        client.start();
    }
}
