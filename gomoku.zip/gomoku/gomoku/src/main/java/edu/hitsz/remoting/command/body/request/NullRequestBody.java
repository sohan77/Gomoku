package edu.hitsz.remoting.command.body.request;

import edu.hitsz.remoting.command.body.AbstractRemotingCommandBody;

public class NullRequestBody extends AbstractRemotingCommandBody {

    @Override
    public void checkFields() throws Exception {
        // TODO Auto-generated method stub

    }

}
