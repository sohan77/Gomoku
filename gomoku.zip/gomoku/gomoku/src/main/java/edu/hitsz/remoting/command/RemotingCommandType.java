package edu.hitsz.remoting.command;

public enum RemotingCommandType {
    REQUEST_COMMAND,
    RESPONSE_COMMAND;
}