package edu.hitsz.remoting.netty;

import edu.hitsz.remoting.*;

public class NettyRemotingFactory implements RemotingFactory {

    @Override
    public RemotingServer createRemotingServer(RemotingServerConfig remotingServerConfig) {
        return null;
    }

    @Override
    public RemotingClient createRemotingClient(RemotingClientConfig remotingClientConfig) {
        // TODO Auto-generated method stub
        return null;
    }


}
