package edu.hitsz.remoting;

public interface ChannelHandler {

    ChannelHandler addListener(ChannelHandlerListener listenr);
}
