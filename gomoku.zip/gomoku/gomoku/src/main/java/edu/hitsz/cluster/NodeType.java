package edu.hitsz.cluster;

public enum NodeType {
    SERVER,
    CLIENT;
}
