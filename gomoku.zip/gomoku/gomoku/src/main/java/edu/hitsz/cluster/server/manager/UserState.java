package edu.hitsz.cluster.server.manager;

import java.io.Serializable;

/**
 * Created by Neuclil on 17-4-15.
 */
public enum UserState implements Serializable{
    WAITING,
    GAMING;
}
