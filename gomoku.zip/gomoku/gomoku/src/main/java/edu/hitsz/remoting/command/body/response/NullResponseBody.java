package edu.hitsz.remoting.command.body.response;

import edu.hitsz.remoting.command.body.AbstractRemotingCommandBody;

public class NullResponseBody extends AbstractRemotingCommandBody {

    @Override
    public void checkFields() throws Exception {
        // TODO Auto-generated method stub

    }

}
